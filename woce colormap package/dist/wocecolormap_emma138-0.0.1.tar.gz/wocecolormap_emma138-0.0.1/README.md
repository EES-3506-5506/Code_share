This is a package of the World Ocean Circulation Experiment (woce) colormaps. These colormaps were specific to woce and were not availible in python. Megan Siwak used MatPlotLib to recreate them for data analysis.

Important Notes
- These colormaps cannot be reversed.
- The 'under' label is given to the lower value while the 'over' label is given to the higher value.